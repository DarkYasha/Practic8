package com.avast.android.butterknifezelezny.iface;

public interface ICancelListener {

    public void onCancel();
}
